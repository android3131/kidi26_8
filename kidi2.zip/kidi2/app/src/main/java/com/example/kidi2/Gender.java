package com.example.kidi2;

public enum Gender {
    Boy,Girl,NotRelevant
}